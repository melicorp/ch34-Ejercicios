console.log("Hola desde la terminal");
console.log("Sesion CS01 en Ch34");
